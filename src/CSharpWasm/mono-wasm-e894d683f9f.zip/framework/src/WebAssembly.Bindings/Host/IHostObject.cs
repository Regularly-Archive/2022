﻿using System;
namespace WebAssembly.Host {
	public interface IHostObject {

	}
}
